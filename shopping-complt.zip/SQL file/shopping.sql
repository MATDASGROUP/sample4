-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2023 at 03:41 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopping`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'admin', 'f925916e2754e5e03f75dd58a5733251', '2017-01-24 16:21:18', '21-06-2018 08:27:55 PM');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(255) DEFAULT NULL,
  `categoryDescription` longtext DEFAULT NULL,
  `creationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categoryDescription`, `creationDate`, `updationDate`) VALUES
(3, 'Textbooks', 'Textbooks', '2017-01-24 19:17:37', '13-09-2023 08:49:57 PM'),
(4, 'Buy For Schools', 'for schools', '2017-01-24 19:19:32', '13-09-2023 08:51:03 PM'),
(5, 'Sci-Fi Short Story', 'Science fiction short storys', '2017-01-24 19:19:54', '13-09-2023 08:52:57 PM'),
(6, 'Scholar', 'Scholar', '2017-02-20 19:18:52', '13-09-2023 08:54:38 PM'),
(7, 'Science', 'Science books', '2023-09-13 12:55:47', NULL),
(8, 'Brainbox', 'brainbox page', '2023-09-15 12:28:16', NULL),
(9, 'Brainbox', 'brainbox page', '2023-09-15 12:33:42', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` varchar(255) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `orderDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `paymentMethod` varchar(50) DEFAULT NULL,
  `orderStatus` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `userId`, `productId`, `quantity`, `orderDate`, `paymentMethod`, `orderStatus`) VALUES
(1, 1, '3', 1, '2017-03-07 19:32:57', 'COD', NULL),
(3, 1, '4', 1, '2017-03-10 19:43:04', 'Debit / Credit card', 'Delivered'),
(4, 1, '17', 1, '2017-03-08 16:14:17', 'COD', 'in Process'),
(5, 1, '3', 1, '2017-03-08 19:21:38', 'COD', NULL),
(6, 1, '4', 1, '2017-03-08 19:21:38', 'COD', NULL),
(7, 4, '3', 2, '2023-09-13 12:51:04', 'Debit / Credit card', 'in Process'),
(8, 4, '4', 2, '2023-09-13 12:51:04', 'Debit / Credit card', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ordertrackhistory`
--

CREATE TABLE `ordertrackhistory` (
  `id` int(11) NOT NULL,
  `orderId` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `remark` mediumtext DEFAULT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `ordertrackhistory`
--

INSERT INTO `ordertrackhistory` (`id`, `orderId`, `status`, `remark`, `postingDate`) VALUES
(1, 3, 'in Process', 'Order has been Shipped.', '2017-03-10 19:36:45'),
(2, 1, 'Delivered', 'Order Has been delivered', '2017-03-10 19:37:31'),
(3, 3, 'Delivered', 'Product delivered successfully', '2017-03-10 19:43:04'),
(4, 4, 'in Process', 'Product ready for Shipping', '2017-03-10 19:50:36'),
(5, 7, 'in Process', 'in process', '2023-09-13 12:55:11');

-- --------------------------------------------------------

--
-- Table structure for table `productreviews`
--

CREATE TABLE `productreviews` (
  `id` int(11) NOT NULL,
  `productId` int(11) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `value` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `summary` varchar(255) DEFAULT NULL,
  `review` longtext DEFAULT NULL,
  `reviewDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `productreviews`
--

INSERT INTO `productreviews` (`id`, `productId`, `quality`, `price`, `value`, `name`, `summary`, `review`, `reviewDate`) VALUES
(2, 3, 4, 5, 5, 'Anuj Kumar', 'BEST PRODUCT FOR ME :)', 'BEST PRODUCT FOR ME :)', '2017-02-26 20:43:57'),
(3, 3, 3, 4, 3, 'Sarita pandey', 'Nice Product', 'Value for money', '2017-02-26 20:52:46'),
(4, 3, 3, 4, 3, 'Sarita pandey', 'Nice Product', 'Value for money', '2017-02-26 20:59:19');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` int(11) NOT NULL,
  `subCategory` int(11) DEFAULT NULL,
  `productName` varchar(255) DEFAULT NULL,
  `productCompany` varchar(255) DEFAULT NULL,
  `productPrice` int(11) DEFAULT NULL,
  `productPriceBeforeDiscount` int(11) DEFAULT NULL,
  `productDescription` longtext DEFAULT NULL,
  `productImage1` varchar(255) DEFAULT NULL,
  `productImage2` varchar(255) DEFAULT NULL,
  `productImage3` varchar(255) DEFAULT NULL,
  `shippingCharge` int(11) DEFAULT NULL,
  `productAvailability` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category`, `subCategory`, `productName`, `productCompany`, `productPrice`, `productPriceBeforeDiscount`, `productDescription`, `productImage1`, `productImage2`, `productImage3`, `shippingCharge`, `productAvailability`, `postingDate`, `updationDate`) VALUES
(1, 4, 3, 'Bilingual in Social Studies (Primary 3)', 'Gbolahan Aduke Olukemi', 20, 30, 'Social Studies in Yoruba language', 'pro10.jpg', 'pro10.jpg', 'pro10.jpg', 0, 'In Stock', '2017-01-30 16:54:35', ''),
(2, 4, 4, 'ABD Matimatiiki Alakobere Iwe Kin-in-ni', 'Gbolahan Aduke Olukemi', 30, 45, 'Mathematics in Yoruba language', 'pro11.jpg', 'pro11.jpg', 'pro11.jpg', 0, 'In Stock', '2017-01-30 16:59:00', ''),
(14, 4, 6, 'Yoruba - English Dictionary', 'Kayode J. Fakinlede Ph. D', 35, 50, 'Yoruba -  English dictionary', 'pro5.jpg', 'pro5.jpg', 'pro5.jpg', 0, 'In Stock', '2017-02-04 04:32:15', ''),
(21, 3, 13, 'ABD MATIMATIIKI', 'Bode Oje', 0, 0, 'its a textbook that teaches mathematics in Yoruba Language.', 'pro11.jpg', 'pro12.jpg', 'pro12.jpg', 0, 'In Stock', '2023-09-13 13:04:31', NULL),
(22, 7, 14, 'Science and Tech Handbook', 'Kayode J. Fakinlede Ph. D', 20, 29, 'Science and Technology handbook', 'pro20.png', 'pro20.png', 'pro20.png', 0, 'In Stock', '2023-09-15 12:42:29', NULL),
(23, 7, 14, 'Iwe Imo Ijinle Eekefa', 'Kayode J. Fakinlede Ph. D', 20, 35, 'health and environmental science.', 'pro19.png', 'pro19.png', 'pro19.png', 0, 'In Stock', '2023-09-15 12:46:10', NULL),
(24, 7, 14, 'Iwe Imo Ijinle Eekarun', 'Kayode J. Fakinlede Ph. D', 20, 40, 'mathematics  science', 'pro18.png', 'pro18.png', 'pro18.png', 0, 'In Stock', '2023-09-15 12:48:26', NULL),
(25, 7, 14, 'Iwe Imo Ijinle Eekerin', 'Kayode J. Fakinlede Ph. D', 20, 32, 'physical science', 'pro17.png', 'pro17.png', 'pro17.png', 0, 'In Stock', '2023-09-15 12:53:47', NULL),
(26, 7, 14, 'Iwe Imo Ijinle Eeketa', 'Kayode J. Fakinlede Ph. D', 20, 32, 'biological science', 'pro16.png', 'pro16.png', 'pro16.png', 0, 'In Stock', '2023-09-15 12:56:21', NULL),
(27, 7, 14, 'Iwe Imo Ijinle Ekeji', 'Kayode J. Fakinlede Ph. D', 20, 35, 'earth science and astronomy', 'pro15.png', 'pro15.png', 'pro15.png', 0, 'In Stock', '2023-09-15 12:58:33', NULL),
(28, 7, 14, 'Iwe Imo Ijinle Ekini', 'Kayode J. Fakinlede Ph. D', 22, 40, 'introduction to science', 'pro14.png', 'pro14.png', 'pro14.png', 0, 'In Stock', '2023-09-15 13:00:44', NULL),
(29, 3, 16, 'ABD Matimatiiki Alakobere Iwe Keta', 'Gbolahan Aduke Olukemi', 20, 35, 'mathematics in Yoruba language.', 'pro13.jpg', 'pro13.jpg', 'pro13.jpg', 0, 'In Stock', '2023-09-15 13:04:48', NULL),
(30, 3, 16, 'ABD Matimatiiki Alakobere Iwe Keji', 'Gbolahan Aduke Olukemi', 20, 38, 'mathematics in Yoruba language book 2', 'pro12.jpg', 'pro12.jpg', 'pro12.jpg', 0, 'In Stock', '2023-09-15 13:06:40', NULL),
(31, 3, 16, 'ABD Matimatiiki Alakobere Iwe Kin-in-ni', 'Gbolahan Aduke Olukemi', 20, 36, 'mathematics in Yoruba language book 1', 'pro11.jpg', 'pro11.jpg', 'pro11.jpg', 0, 'In Stock', '2023-09-15 13:08:25', NULL),
(32, 3, 18, 'Bilingual in Social Studies (Primary 3)', 'Gbolahan Aduke Olukemi', 20, 25, 'Social Studies in Yoruba language for primary 3', 'pro10.jpg', 'pro10.jpg', 'pro10.jpg', 0, 'In Stock', '2023-09-15 13:12:31', NULL),
(33, 3, 18, 'Bilingual in Social Studies (Primary 2)', 'Gbolahan Aduke Olukemi', 20, 29, 'Social Studies in Yoruba language for primary 2', 'pro9.jpg', 'pro9.jpg', 'pro9.jpg', 0, 'In Stock', '2023-09-15 13:14:37', NULL),
(34, 3, 18, 'Bilingual in Social Studies (Primary 1)', 'Gbolahan Aduke Olukemi', 21, 32, 'Social Studies in Yoruba language for primary 1', 'pro8.jpg', 'pro8.jpg', 'pro8.jpg', 0, 'In Stock', '2023-09-15 13:16:16', NULL),
(35, 5, 9, 'Olojo', 'Bode Oje', 20, 40, 'Sequel to Irin ajo sinu ayedimeji', 'pro7.jpg', 'pro7.jpg', 'pro7.jpg', 0, 'In Stock', '2023-09-15 13:20:47', NULL),
(36, 3, 16, 'English - Yoruba Mathematics', 'Kayode J. Fakinlede Ph. D', 30, 50, 'Training workbook', 'pro6.jpg', 'pro6.jpg', 'pro6.jpg', 0, 'In Stock', '2023-09-15 13:23:16', NULL),
(37, 3, 20, 'Yoruba - English Dictionary', 'Kayode J. Fakinlede Ph. D', 28, 45, 'Yoruba to English dictionary', 'pro5.jpg', 'pro5.jpg', 'pro5.jpg', 0, 'In Stock', '2023-09-15 13:26:44', NULL),
(38, 3, 21, 'Beginners Yoruba', 'Kayode J. Fakinlede Ph. D', 22, 30, 'Yoruba for all beginners', 'pro4.jpg', 'pro4.jpg', 'pro4.jpg', 0, 'In Stock', '2023-09-15 14:50:31', NULL),
(39, 4, 3, 'Awa Yoruba', 'Kayode J. Fakinlede Ph. D', 19, 29, 'Iwe aworan fun awon ile omo Yoruba', 'pro2.jpg', 'pro2.jpg', 'pro2.jpg', 0, 'In Stock', '2023-09-15 14:53:40', NULL),
(40, 7, 14, 'Irin Ajo Sinu Ayedimeji', 'Bode Oje', 19, 31, 'Irin Ajo Sinu Ayedimeji', 'pro1.jpg', 'pro1.jpg', 'pro1.jpg', 0, 'In Stock', '2023-09-15 14:55:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `categoryid` int(11) DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `categoryid`, `subcategory`, `creationDate`, `updationDate`) VALUES
(3, 4, 'textbook', '2017-01-26 16:29:09', '15-09-2023 07:27:41 PM'),
(4, 4, 'Science', '2017-01-30 16:55:48', '15-09-2023 07:28:04 PM'),
(6, 4, 'dictionary', '2017-02-04 04:13:00', '15-09-2023 07:28:33 PM'),
(9, 5, 'Science', '2017-02-04 04:36:45', '15-09-2023 06:47:50 PM'),
(12, 6, 'Men Footwears', '2017-03-10 20:12:59', ''),
(13, 3, 'Science', '2023-09-13 12:58:20', NULL),
(14, 7, 'Science', '2023-09-15 12:38:33', NULL),
(15, 7, 'Technology', '2023-09-15 12:38:53', NULL),
(16, 3, 'Mathematics', '2023-09-15 13:01:24', NULL),
(17, 3, 'English', '2023-09-15 13:01:39', NULL),
(18, 3, 'Social Studies', '2023-09-15 13:09:05', NULL),
(19, 5, 'Technology', '2023-09-15 13:18:35', NULL),
(20, 3, 'dictionary', '2023-09-15 13:24:29', NULL),
(21, 3, 'Yoruba', '2023-09-15 13:28:22', NULL),
(22, 4, 'textbook', '2023-09-15 13:50:29', NULL),
(23, 3, 'Science', '2023-09-15 13:50:38', NULL),
(24, 3, 'dictionary', '2023-09-15 13:50:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `userEmail`, `userip`, `loginTime`, `logout`, `status`) VALUES
(1, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 11:18:50', '', 1),
(2, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 11:29:33', '', 1),
(3, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 11:30:11', '', 1),
(4, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 15:00:23', '26-02-2017 11:12:06 PM', 1),
(5, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 18:08:58', '', 0),
(6, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 18:09:41', '', 0),
(7, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 18:10:04', '', 0),
(8, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 18:10:31', '', 0),
(9, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-26 18:13:43', '', 1),
(10, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-27 18:52:58', '', 0),
(11, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-02-27 18:53:07', '', 1),
(12, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-03 18:00:09', '', 0),
(13, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-03 18:00:15', '', 1),
(14, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-06 18:10:26', '', 1),
(15, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-07 12:28:16', '', 1),
(16, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-07 18:43:27', '', 1),
(17, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-07 18:55:33', '', 1),
(18, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-07 19:44:29', '', 1),
(19, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-08 19:21:15', '', 1),
(20, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-15 17:19:38', '', 1),
(21, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-15 17:20:36', '15-03-2017 10:50:39 PM', 1),
(22, 'anuj.lpu1@gmail.com', 0x3a3a3100000000000000000000000000, '2017-03-16 01:13:57', '', 1),
(23, 'hgfhgf@gmass.com', 0x3a3a3100000000000000000000000000, '2018-04-29 09:30:40', '', 1),
(24, 'temitope4love100@gmail.com', 0x3a3a3100000000000000000000000000, '2023-09-13 12:50:56', '15-09-2023 05:22:14 PM', 1),
(25, 'temitope4love100@gmail.com', 0x3a3a3100000000000000000000000000, '2023-09-15 11:53:16', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `shippingAddress` longtext DEFAULT NULL,
  `shippingState` varchar(255) DEFAULT NULL,
  `shippingCity` varchar(255) DEFAULT NULL,
  `shippingPincode` int(11) DEFAULT NULL,
  `billingAddress` longtext DEFAULT NULL,
  `billingState` varchar(255) DEFAULT NULL,
  `billingCity` varchar(255) DEFAULT NULL,
  `billingPincode` int(11) DEFAULT NULL,
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `contactno`, `password`, `shippingAddress`, `shippingState`, `shippingCity`, `shippingPincode`, `billingAddress`, `billingState`, `billingCity`, `billingPincode`, `regDate`, `updationDate`) VALUES
(1, 'Anuj Kumar', 'anuj.lpu1@gmail.com', 9009857868, 'f925916e2754e5e03f75dd58a5733251', 'CS New Delhi', 'New Delhi', 'Delhi', 110001, 'New Delhi', 'New Delhi', 'Delhi', 110092, '2017-02-04 19:30:50', ''),
(2, 'Amit ', 'amit@gmail.com', 8285703355, '5c428d8875d2948607f3e3fe134d71b4', '', '', '', 0, '', '', '', 0, '2017-03-15 17:21:22', ''),
(3, 'hg', 'hgfhgf@gmass.com', 1121312312, '827ccb0eea8a706c4c34a16891f84e7b', '', '', '', 0, '', '', '', 0, '2018-04-29 09:30:32', ''),
(4, 'Temitope Daniel', 'temitope4love100@gmail.com', 8132413970, 'e10adc3949ba59abbe56e057f20f883e', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-09-13 12:50:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

CREATE TABLE `wishlist` (
  `id` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `productId` int(11) DEFAULT NULL,
  `postingDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `wishlist`
--

INSERT INTO `wishlist` (`id`, `userId`, `productId`, `postingDate`) VALUES
(1, 1, 0, '2017-02-27 18:53:17'),
(2, 4, 9, '2023-09-15 21:35:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordertrackhistory`
--
ALTER TABLE `ordertrackhistory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `productreviews`
--
ALTER TABLE `productreviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wishlist`
--
ALTER TABLE `wishlist`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `ordertrackhistory`
--
ALTER TABLE `ordertrackhistory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `productreviews`
--
ALTER TABLE `productreviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `wishlist`
--
ALTER TABLE `wishlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
